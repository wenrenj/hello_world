//: Playground - noun: a place where people can play

import UIKit

var str = "<NewAttachDevice>Hello, playground</NewAttachDevice>"

print(str)

var dic:[String:AnyObject] = [:]
print(dic.count)
